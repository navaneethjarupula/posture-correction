export interface PostureCategory {
  id: string;
  title: string;
  description: string;
  image: string;
  subcategories: PostureSubcategory[];
}

export interface PostureSubcategory {
  id: string;
  title: string;
  description: string;
  image: string;
  correctPosture: string[];
  commonMistakes: string[];
  tips: string[];
}