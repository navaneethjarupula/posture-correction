import { create } from 'zustand';
import { PostureCategory } from '../types';

interface PostureStore {
  categories: PostureCategory[];
  selectedCategory: PostureCategory | null;
  setSelectedCategory: (category: PostureCategory | null) => void;
}

export const usePostureStore = create<PostureStore>((set) => ({
  categories: [
    {
      id: 'gym',
      title: 'Gym Postures',
      description: 'Master proper form for various gym exercises',
      image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48',
      subcategories: [
        {
          id: 'biceps',
          title: 'Biceps',
          description: 'Perfect form for bicep exercises',
          image: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e',
          correctPosture: [
            'Keep your back straight and core engaged',
            'Elbows close to your body',
            'Control the movement throughout',
            'Shoulders back and down'
          ],
          commonMistakes: [
            'Swinging the weights',
            'Using momentum',
            'Poor back posture',
            'Lifting too heavy'
          ],
          tips: [
            'Focus on form over weight',
            'Maintain controlled movements',
            'Keep core engaged',
            'Breathe steadily'
          ]
        },
        {
          id: 'triceps',
          title: 'Triceps',
          description: 'Proper tricep exercise techniques',
          image: 'https://images.unsplash.com/photo-1530822847156-5df684ec5ee1',
          correctPosture: [
            'Keep elbows close to head during extensions',
            'Maintain stable shoulder position',
            'Control the negative movement',
            'Keep core tight'
          ],
          commonMistakes: [
            'Flaring elbows out',
            'Moving shoulders instead of elbows',
            'Rushing the movement',
            'Improper weight selection'
          ],
          tips: [
            'Focus on isolation',
            'Maintain proper elbow position',
            'Control throughout movement',
            'Keep wrists straight'
          ]
        },
        {
          id: 'chest',
          title: 'Chest',
          description: 'Effective chest workout form',
          image: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b',
          correctPosture: [
            'Keep shoulders retracted',
            'Maintain natural arch in lower back',
            'Feet flat on ground or bench',
            'Control bar path'
          ],
          commonMistakes: [
            'Bouncing the bar',
            'Arching back excessively',
            'Uneven bar path',
            'Wrists bent backwards'
          ],
          tips: [
            'Focus on chest contraction',
            'Breathe properly',
            'Keep shoulders stable',
            'Use appropriate grip width'
          ]
        },
        {
          id: 'lats',
          title: 'Lats',
          description: 'Proper lat exercise execution',
          image: 'https://images.unsplash.com/photo-1541534741688-6078c6bfb5c5',
          correctPosture: [
            'Engage lats before pulling',
            'Keep chest up',
            'Maintain neutral spine',
            'Control the movement'
          ],
          commonMistakes: [
            'Using momentum',
            'Poor range of motion',
            'Rounded shoulders',
            'Jerking movements'
          ],
          tips: [
            'Focus on lat engagement',
            'Maintain scapular control',
            'Use appropriate weight',
            'Control eccentric phase'
          ]
        },
        {
          id: 'shoulders',
          title: 'Shoulders',
          description: 'Safe and effective shoulder training',
          image: 'https://images.unsplash.com/photo-1532029837206-abbe2b7620e3',
          correctPosture: [
            'Keep core engaged',
            'Control the movement',
            'Maintain neutral spine',
            'Keep shoulders down'
          ],
          commonMistakes: [
            'Using momentum',
            'Poor range of motion',
            'Lifting too heavy',
            'Improper breathing'
          ],
          tips: [
            'Focus on controlled movement',
            'Maintain proper form',
            'Warm up thoroughly',
            'Progress gradually'
          ]
        },
        {
          id: 'legs',
          title: 'Legs',
          description: 'Proper leg exercise techniques',
          image: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155',
          correctPosture: [
            'Keep chest up',
            'Knees tracking over toes',
            'Maintain neutral spine',
            'Engage core throughout'
          ],
          commonMistakes: [
            'Knees caving in',
            'Rounding lower back',
            'Incomplete depth',
            'Poor weight distribution'
          ],
          tips: [
            'Focus on proper depth',
            'Maintain knee alignment',
            'Keep weight on heels',
            'Breathe consistently'
          ]
        }
      ]
    },
    {
      id: 'bike',
      title: 'Bike Postures',
      description: 'Optimal cycling positions for different styles',
      image: 'https://images.unsplash.com/photo-1541625602330-2277a4c46182',
      subcategories: [
        {
          id: 'commuter',
          title: 'Commuter Cycling',
          description: 'Comfortable position for daily rides',
          image: 'https://images.unsplash.com/photo-1582649475939-c84952e8f1a5',
          correctPosture: [
            'Slight forward lean',
            'Relaxed arms',
            'Neutral spine',
            'Proper seat height'
          ],
          commonMistakes: [
            'Seat too low',
            'Hunched shoulders',
            'Locked elbows',
            'Poor handlebar position'
          ],
          tips: [
            'Adjust seat height properly',
            'Keep arms slightly bent',
            'Look ahead while riding',
            'Regular position checks'
          ]
        },
        {
          id: 'sports',
          title: 'Sports Cycling',
          description: 'Aerodynamic position for performance',
          image: 'https://images.unsplash.com/photo-1517649763962-0c623066013b',
          correctPosture: [
            'Lower aerodynamic position',
            'Flat back angle',
            'Relaxed upper body',
            'Proper hip angle'
          ],
          commonMistakes: [
            'Too aggressive position',
            'Tense shoulders',
            'Improper cleat position',
            'Poor weight distribution'
          ],
          tips: [
            'Build flexibility',
            'Regular bike fitting',
            'Core strengthening',
            'Gradual position adaptation'
          ]
        }
      ]
    },
    {
      id: 'desk',
      title: 'Desk Posture',
      description: 'Ergonomic workspace positioning',
      image: 'https://images.unsplash.com/photo-1541746972996-4e0b0f43e02a',
      subcategories: [
        {
          id: 'sitting',
          title: 'Sitting Posture',
          description: 'Proper desk ergonomics',
          image: 'https://images.unsplash.com/photo-1599045118108-bf9954418b76',
          correctPosture: [
            'Screen at eye level',
            'Feet flat on ground',
            'Back straight against chair',
            '90-degree elbow angle'
          ],
          commonMistakes: [
            'Slouching',
            'Screen too low',
            'Crossed legs',
            'Wrists not supported'
          ],
          tips: [
            'Regular breaks',
            'Proper chair height',
            'Use ergonomic equipment',
            'Stretch regularly'
          ]
        }
      ]
    },
    {
      id: 'sleeping',
      title: 'Sleeping Posture',
      description: 'Optimal positions for restful sleep',
      image: 'https://images.unsplash.com/photo-1631155908067-1b6addf2972e',
      subcategories: [
        {
          id: 'back',
          title: 'Back Sleeping',
          description: 'Proper alignment while sleeping on back',
          image: 'https://images.unsplash.com/photo-1631155906824-ff2ac01c3d25',
          correctPosture: [
            'Neutral spine alignment',
            'Proper pillow height',
            'Arms relaxed at sides',
            'Knees slightly supported'
          ],
          commonMistakes: [
            'Pillow too high',
            'Neck twisted',
            'Lower back unsupported',
            'Poor mattress support'
          ],
          tips: [
            'Use supportive mattress',
            'Maintain neutral spine',
            'Consider pillow under knees',
            'Regular pillow replacement'
          ]
        }
      ]
    },
    {
      id: 'driving',
      title: 'Driving Posture',
      description: 'Safe and comfortable driving positions',
      image: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2',
      subcategories: [
        {
          id: 'car',
          title: 'Car Driving',
          description: 'Ergonomic car driving position',
          image: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2',
          correctPosture: [
            'Proper seat distance',
            'Correct backrest angle',
            'Hands at 9 and 3',
            'Head against headrest'
          ],
          commonMistakes: [
            'Seat too far/close',
            'Improper lumbar support',
            'Slouching',
            'Arms too straight'
          ],
          tips: [
            'Adjust mirrors properly',
            'Regular position checks',
            'Use lumbar support',
            'Take breaks on long drives'
          ]
        }
      ]
    },
    {
      id: 'standing',
      title: 'Standing Posture',
      description: 'Proper standing techniques',
      image: 'https://images.unsplash.com/photo-1551033406-611cf9a28f67',
      subcategories: [
        {
          id: 'presentation',
          title: 'Presentation Stance',
          description: 'Confident speaking position',
          image: 'https://images.unsplash.com/photo-1557426272-fc759fdf7a8d',
          correctPosture: [
            'Feet shoulder-width apart',
            'Shoulders back and down',
            'Chin parallel to ground',
            'Weight evenly distributed'
          ],
          commonMistakes: [
            'Shifting weight constantly',
            'Crossed legs',
            'Hands in pockets',
            'Slouched shoulders'
          ],
          tips: [
            'Practice power poses',
            'Maintain eye contact',
            'Use purposeful gestures',
            'Stay grounded'
          ]
        }
      ]
    },
    {
      id: 'music',
      title: 'Musical Instrument Posture',
      description: 'Proper positioning for musicians',
      image: 'https://images.unsplash.com/photo-1511192336575-5a79af67a629',
      subcategories: [
        {
          id: 'piano',
          title: 'Piano Posture',
          description: 'Correct piano playing position',
          image: 'https://images.unsplash.com/photo-1552422535-c45813c61732',
          correctPosture: [
            'Proper bench height',
            'Straight back',
            'Relaxed shoulders',
            'Proper arm angle'
          ],
          commonMistakes: [
            'Hunched shoulders',
            'Wrists too high/low',
            'Sitting too close/far',
            'Tense fingers'
          ],
          tips: [
            'Regular posture checks',
            'Take frequent breaks',
            'Adjust bench properly',
            'Stay relaxed'
          ]
        }
      ]
    },
    {
      id: 'yoga',
      title: 'Yoga Posture',
      description: 'Proper alignment for yoga poses',
      image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b',
      subcategories: [
        {
          id: 'basic',
          title: 'Basic Poses',
          description: 'Fundamental yoga positions',
          image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b',
          correctPosture: [
            'Proper alignment',
            'Controlled breathing',
            'Engaged core',
            'Balanced weight distribution'
          ],
          commonMistakes: [
            'Forcing positions',
            'Holding breath',
            'Poor alignment',
            'Rushing movements'
          ],
          tips: [
            'Focus on breath',
            'Listen to your body',
            'Build gradually',
            'Maintain awareness'
          ]
        }
      ]
    },
    {
      id: 'walking',
      title: 'Walking Posture',
      description: 'Proper walking technique',
      image: 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8',
      subcategories: [
        {
          id: 'general',
          title: 'General Walking',
          description: 'Correct walking form',
          image: 'https://images.unsplash.com/photo-1476480862126-209bfaa8edc8',
          correctPosture: [
            'Head up, eyes forward',
            'Shoulders relaxed',
            'Arms swing naturally',
            'Heel-to-toe movement'
          ],
          commonMistakes: [
            'Looking down',
            'Slouched posture',
            'Rigid arm movement',
            'Poor foot placement'
          ],
          tips: [
            'Maintain good posture',
            'Walk heel to toe',
            'Keep natural rhythm',
            'Stay relaxed'
          ]
        }
      ]
    }
  ],
  selectedCategory: null,
  setSelectedCategory: (category) => set({ selectedCategory: category }),
}));