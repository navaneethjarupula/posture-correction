import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Activity } from 'lucide-react';

const Navigation: React.FC = () => {
  const location = useLocation();

  return (
    <nav className="bg-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center gap-2">
              <Activity className="w-8 h-8 text-blue-600" />
              <span className="font-bold text-xl">PostureAI</span>
            </Link>
          </div>
          
          <div className="flex items-center space-x-4">
            <Link
              to="/categories"
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                location.pathname === '/categories'
                  ? 'bg-blue-100 text-blue-700'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              Categories
            </Link>
            <Link
              to="/analysis"
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                location.pathname === '/analysis'
                  ? 'bg-blue-100 text-blue-700'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              Live Analysis
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};