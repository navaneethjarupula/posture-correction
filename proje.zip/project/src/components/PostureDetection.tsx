import React, { useEffect, useRef, useState } from 'react';
import * as tf from '@tensorflow/tfjs';
import * as poseDetection from '@tensorflow-models/pose-detection';
import { Camera } from 'lucide-react';

const PostureDetection: React.FC = () => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  useEffect(() => {
    let detector: poseDetection.PoseDetector;

    const initializeDetector = async () => {
      await tf.ready();
      const model = poseDetection.SupportedModels.BlazePose;
      detector = await poseDetection.createDetector(model, {
        runtime: 'tfjs',
      });
    };

    initializeDetector();

    return () => {
      if (detector) {
        detector.dispose();
      }
    };
  }, []);

  const startAnalysis = async () => {
    if (!videoRef.current) return;

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      videoRef.current.srcObject = stream;
      setIsAnalyzing(true);
    } catch (error) {
      console.error('Error accessing camera:', error);
    }
  };

  return (
    <div className="relative w-full max-w-2xl mx-auto">
      <div className="aspect-video bg-gray-900 rounded-lg overflow-hidden">
        <video
          ref={videoRef}
          className="w-full h-full object-cover"
          autoPlay
          playsInline
        />
        <canvas
          ref={canvasRef}
          className="absolute top-0 left-0 w-full h-full"
        />
      </div>
      
      {!isAnalyzing && (
        <button
          onClick={startAnalysis}
          className="mt-4 flex items-center justify-center w-full gap-2 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Camera className="w-5 h-5" />
          Start Posture Analysis
        </button>
      )}
    </div>
  );
};

export default PostureDetection;