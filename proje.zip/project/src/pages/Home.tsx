import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Activity, Award, Camera } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="space-y-16">
      <section className="text-center space-y-6">
        <h1 className="text-5xl font-bold text-gray-900">
          Perfect Your Posture with AI
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Get real-time posture analysis and guidance for various activities using advanced AI technology.
        </p>
        <div className="flex justify-center gap-4">
          <Link
            to="/categories"
            className="inline-flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Explore Categories
            <ArrowRight className="w-5 h-5" />
          </Link>
          <Link
            to="/analysis"
            className="inline-flex items-center gap-2 bg-white text-blue-600 px-6 py-3 rounded-lg border border-blue-600 hover:bg-blue-50 transition-colors"
          >
            Try Live Analysis
            <Camera className="w-5 h-5" />
          </Link>
        </div>
      </section>

      <section className="grid md:grid-cols-3 gap-8">
        <div className="bg-white p-6 rounded-xl shadow-sm">
          <Activity className="w-12 h-12 text-blue-600 mb-4" />
          <h3 className="text-xl font-semibold mb-2">Comprehensive Guide</h3>
          <p className="text-gray-600">
            Detailed instructions for various activities including gym exercises, desk work, and more.
          </p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm">
          <Camera className="w-12 h-12 text-blue-600 mb-4" />
          <h3 className="text-xl font-semibold mb-2">Real-time Analysis</h3>
          <p className="text-gray-600">
            Get instant feedback on your posture using our advanced AI-powered analysis.
          </p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm">
          <Award className="w-12 h-12 text-blue-600 mb-4" />
          <h3 className="text-xl font-semibold mb-2">Expert Tips</h3>
          <p className="text-gray-600">
            Learn from detailed tips and common mistakes to improve your form.
          </p>
        </div>
      </section>
    </div>
  );
};