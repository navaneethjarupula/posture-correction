import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { usePostureStore } from '../store/usePostureStore';
import { CheckCircle, XCircle, Info, ArrowLeft } from 'lucide-react';

const CategoryDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { categories } = usePostureStore();
  const category = categories.find((c) => c.id === id);

  if (!category) {
    return (
      <div className="text-center py-16">
        <h2 className="text-2xl font-semibold text-gray-900">Category not found</h2>
        <Link
          to="/categories"
          className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700 mt-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Categories
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-4 mb-8">
        <Link
          to="/categories"
          className="inline-flex items-center gap-2 text-blue-600 hover:text-blue-700"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Categories
        </Link>
      </div>

      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">{category.title}</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">{category.description}</p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {category.subcategories.map((subcategory) => (
          <div
            key={subcategory.id}
            className="bg-white rounded-xl shadow-sm overflow-hidden"
          >
            <div className="aspect-video relative overflow-hidden">
              <img
                src={subcategory.image}
                alt={subcategory.title}
                className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-300"
              />
            </div>
            <div className="p-6 space-y-6">
              <div>
                <h3 className="text-2xl font-semibold mb-2">{subcategory.title}</h3>
                <p className="text-gray-600">{subcategory.description}</p>
              </div>

              <div className="space-y-6">
                <div>
                  <h4 className="flex items-center gap-2 font-semibold text-green-600 mb-3">
                    <CheckCircle className="w-5 h-5" />
                    Correct Posture
                  </h4>
                  <ul className="space-y-2">
                    {subcategory.correctPosture.map((item, index) => (
                      <li key={index} className="flex items-start gap-2 text-gray-700">
                        <span className="text-green-500 mt-1">•</span>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="flex items-center gap-2 font-semibold text-red-600 mb-3">
                    <XCircle className="w-5 h-5" />
                    Common Mistakes
                  </h4>
                  <ul className="space-y-2">
                    {subcategory.commonMistakes.map((item, index) => (
                      <li key={index} className="flex items-start gap-2 text-gray-700">
                        <span className="text-red-500 mt-1">•</span>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="flex items-center gap-2 font-semibold text-blue-600 mb-3">
                    <Info className="w-5 h-5" />
                    Pro Tips
                  </h4>
                  <ul className="space-y-2">
                    {subcategory.tips.map((item, index) => (
                      <li key={index} className="flex items-start gap-2 text-gray-700">
                        <span className="text-blue-500 mt-1">•</span>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};