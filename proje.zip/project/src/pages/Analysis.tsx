import React from 'react';
import PostureDetection from '../components/PostureDetection';

const Analysis: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Live Posture Analysis</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Get real-time feedback on your posture using our AI-powered analysis tool
        </p>
      </div>

      <PostureDetection />

      <div className="bg-white p-6 rounded-lg shadow-sm">
        <h2 className="text-2xl font-semibold mb-4">How it works</h2>
        <ol className="list-decimal list-inside space-y-2 text-gray-700">
          <li>Position yourself in front of your camera</li>
          <li>Click the "Start Posture Analysis" button</li>
          <li>Follow the on-screen guidance</li>
          <li>Receive real-time feedback on your posture</li>
        </ol>
      </div>
    </div>
  );
};

export default Analysis;